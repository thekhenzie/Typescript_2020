enum Category { Biography, Poetry, Fiction, History, Children, Software }

export { Category };