var UniversityLibrarian = (function () {
    function UniversityLibrarian() {
    }
    UniversityLibrarian.prototype.assistCustomer = function (custName) {
        console.log(this.name + ' is assisting ' + custName);
    };
    return UniversityLibrarian;
})();
exports.UniversityLibrarian = UniversityLibrarian;
//# sourceMappingURL=classes.js.map